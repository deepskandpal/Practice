/*:
 # Basic Functions
 ---
 
 ## Topic Essentials
 Functions are blocks of code that we can define and call by name to perform whatever tasks we’ve coded into them. Functions can have parameters, which you can think of as inputs, and return values, which you can think of as output.
 
 ### Objectives
 + Create a simple function called **saluteHunter** that prints out a string
 + Create a function called **findNearestFriend** with a return type and have it return a string
 + Create a function called **equipItems** with a parameter and return type
 */
// Basic function - no parameter or return type

// Basic function with return type - no paramaters

// Basic function with return type and parameter

//: [Next Topic](@next)
func saluteHunter () {
    print("hello there intrepid hunter")
}

saluteHunter()

func findNearestHunter() -> String{
    return "Argus"
    
}

var nearMe = findNearestHunter()

func equippedItems (armour : String) -> Bool {
    print("\(armour) successfully equipped")
    return true
}

equippedItems(armour: "Deamon vest")


func requestItemTrade (myItem : String) -> (yourItem: String, value :Int){
 print("can I trade my \(myItem)?")
 return ("Sacred Sheild " , 300)
}

let tradeItem = requestItemTrade(myItem: "Old Hat")

print("recieved your item \(tradeItem.yourItem), valued at \(tradeItem.value)\n")

func requestTrade (item : String)-> String? {
    let returnItem = "garbage sword"
    return returnItem
}
if let item = requestTrade(item: "Spike Boots"){
    print("\(item) recieved")
    
}
    else {
        print("trade fell through\n")
    }

func setupArenaMatch (level:String = "fire Marshes" , noOfOponents:Int = 2) {
    print("your arena match will take place in \(level) between \(noOfOponents) players")
}

setupArenaMatch()
setupArenaMatch(level : "Poison Flats" ,noOfOponents: 5)

func attack () {
    print("attackinh")
    
}

func attack (damage :Int) {
    print("attacking for \(damage) damage")
}

func attack (damage:Double , weapon: String) -> Bool {
    print("\(damage) done to enemy with \(weapon)")
    return true
}

attack()
attack(damage: 35)
attack(damage: 45, weapon:"Hammer")

func computeBonusDamage (damage:Int) -> Int {
    return damage+1
}

func dealDamage(baseDamage:Int,computeFunc:(Int)->Int) {
    let bonus = computeFunc(baseDamage)
    print("base damage \(baseDamage)\n \(bonus) \n\n  \(bonus + baseDamage) total damage dealt to the enemy")
}

